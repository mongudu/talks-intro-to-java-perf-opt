package com.murat.createthreads;

public class Application {


    public static void main(String[] args) {

        for (int i = 0; i < 1000; i++) {

            final int threadIndex = i;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    System.out.println(threadIndex);

                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            });

            thread.setName(String.valueOf(i));

            thread.start();

            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {

                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }


    }

}
