package com.murat.deadlock;


public class ApplicationDeadLock {

    public static void main(String[] args) {

        ApplicationDeadLock test = new ApplicationDeadLock();

        final FirstResource firstResource = new FirstResource();
        final SecondResource secondResource = new SecondResource();

        // Thread-1
        Runnable runnable1 = new Runnable() {
            public void run() {
                synchronized (firstResource) {
                    System.out.println("block 1 - 1");
                    try {
                        // Adding delay so that both threads can start trying to
                        // lock resources
                        System.out.println("block 1 - 2");
                        Thread.sleep(100);
                        System.out.println("block 1 - 3");
                    } catch (InterruptedException e) {
                        System.out.println("block 1 - 4");
                        e.printStackTrace();
                    }
                    // Thread-1 have Item but need SecondResource also
                    synchronized (secondResource) {
                        System.out.println("block 1 - 5");
                    }
                }
            }
        };



        // Thread-2
        Runnable runnable2 = new Runnable() {
            public void run() {
                synchronized (secondResource) {
                    System.out.println("block 2 - 1");
                    // Thread-2 have SecondResource but need Item also
                    synchronized (firstResource) {
                        System.out.println("block 2 - 2");
                    }
                }
            }
        };

        Thread thread1 = new Thread(runnable1);
        thread1.setName("thread1");
        thread1.start();

        Thread thread2 = new Thread(runnable2);
        thread2.setName("thread2");
        thread2.start();

    }


}

