package com.murat.deadlock;

// Resource Item
class FirstResource {

    private int i = 10;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

}
