package com.murat.deadlock;

// Resource SecondResource
class SecondResource {

    private int i = 20;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }


}
