package com.murat.memoryproblem;

import java.util.ArrayList;
import java.util.List;

public class ApplicationProblem {

    public static void main(String[] args) {

        List<Item> list = new ArrayList<Item>();

        for (int i = 0; i < 1_000_000_000; i++) {
            list.add(new Item("aaa" + i + "."));
            if (i % 10000 == 0) {
                try {
                    Thread.sleep(100L);
                    System.out.println(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }


        }



    }

}
