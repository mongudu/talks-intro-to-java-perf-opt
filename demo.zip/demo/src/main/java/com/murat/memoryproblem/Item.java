package com.murat.memoryproblem;

public class Item {

    private String index;

    public Item(String index) {
        this.index = index;
    }

    public String getIndex() {
        return index;
    }
}
